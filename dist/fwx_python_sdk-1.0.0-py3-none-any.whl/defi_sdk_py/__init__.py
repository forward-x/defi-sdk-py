# from .chain_client import ChainClient
from .fwx_chain import FWXChainClient
from .fwx_chain import ADDRESS as FWX_ADDRESS
from .avax_fuji_chain import AVAXFUJIChainClient
from .avax_fuji_chain import ADDRESS as FUJI_ADDRESS